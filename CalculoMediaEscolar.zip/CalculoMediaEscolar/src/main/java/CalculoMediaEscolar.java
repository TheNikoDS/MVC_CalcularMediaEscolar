/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

/**
 *
 * @author 026623
 */
public class CalculoMediaEscolar {

    public static void main(String[] args) {
       model model = new model();
       view view = new view();
       controller controller = new controller(model,view);
       
       view.setVisible(true);
    }
}
