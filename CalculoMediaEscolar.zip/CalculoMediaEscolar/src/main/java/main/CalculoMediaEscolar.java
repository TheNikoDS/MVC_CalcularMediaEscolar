package main;
public class CalculoMediaEscolar 
{

    public static void main(String[] args) 
    {
        
    }
}
