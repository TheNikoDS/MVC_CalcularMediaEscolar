
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 026623
 */
public class controller {
    private model model;
    private view view;
    
    public controller(model model,view view){
        this.model = model;
        this.view = view;
        this.view.addCalcularListener(new ActionListener(){
            
        @Override 
        public void actionPerformed(ActionEvent e){
            calcularNota();
        }
    });
        
    }
    
    private void calcularNota(){
        try{
            double nota1 = Double.parseDouble(view.getnota1Texto().replace("," , "."));
            double nota2 = Double.parseDouble(view.getnota2Texto().replace("," , "."));
            double nota3 = Double.parseDouble(view.getnota3Texto().replace("," , "."));
            double nota4 = Double.parseDouble(view.getnota4Texto().replace("," , "."));
            double prc = Double.parseDouble(view.getPrcTexto().replace("," , "."));
            
            model.setnota1(nota1);
            model.setnota2(nota2);
            model.setnota3(nota3);
            model.setnota4(nota4);
            model.setprc(prc);
            
            double notafinal = model.calcularmédia();
            String classificacao = model.obterNota(notafinal);
            
            String resultado = String.format(" %.2f %s",notafinal, classificacao);
            view.setResultado(resultado);
            
        }catch(NumberFormatException ex){
            view.exibirMensagemErro("Por favor, insira valores numéricos.");
            
        }catch(IllegalArgumentException ex){
            view.exibirMensagemErro(ex.getMessage());
        }
        
    }
    
}
