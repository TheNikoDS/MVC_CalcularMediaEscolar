/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 026623
 */
public class model {
    private double prc;
    private double nota1;
    private double nota2;
    private double nota3;
    private double nota4;
    
    public void setnota1(double nota1){
        this.nota1 = nota1;
    }
    
    public void setnota2(double nota2){
        this.nota2 = nota2;
    }
    public void setnota3(double nota3){
        this.nota3 = nota3;
    }
     public void setnota4(double nota4){
        this.nota4 = nota4;
    }
    public void setprc(double prc){
    this.prc = prc;
    }
    
    public double calcularmédia(){
         if(prc < 0){
            throw new IllegalArgumentException("Não tem como a porcentagem estar menor que 0");
        }
       return (nota1 + nota2 + nota3 + nota4) / 4;
    }
    
    public String obterNota(double notafinal){
        if (notafinal < 7 && prc >= 75)return "reprovado";
        if (notafinal >= 7 && prc >= 75)return "Aprovado";
        return "reprovado";
        }
        

}
